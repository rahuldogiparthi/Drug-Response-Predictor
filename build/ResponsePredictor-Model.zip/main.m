function DrugResponse_main(inputfile)

    load(inputfile)
    [~,n_drug] = size(drugname);
    feature_left_fix = 1; 
    factor=3/4;
    threshold = 0.5; 
    for drug = 1:n_drug
        DrugResponse_model(inputfile,drug,feature_left_fix,factor,threshold);
    end
end
